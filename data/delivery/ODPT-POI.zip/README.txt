POIs taken from Google Places API for ODPT 2018 project.

Total POI count: 4626
Categories collected:
Amusement park
Aquarium
Art museum
Cafe
Department Store
Museum
Park
Restaurant
Shopping Mall

Collection notes:

"Types" field returned from GP-API does not involve subcategories.

For "Types": most POI have multiple categories assigned (some seem barely related).
Query to GP-API for 'cafe' seems return any record where 'cafe' is listed as a type (even secondary/third type). 
Due to this many duplicate POIs were returned during place search.
Also, categories may not match fully (multiple aquarium/art gallery/restaurant were returned under "Amusement" query, etc.)

Tour location/landmark type categories were not supported in any of the categories: no hits for shrines, Meiji-Jingu, unless museum, amusement attached etc.

POI were queried within distance of 1000~1500m from each busstop, with rating > 4 for restaurant types, > 3 for cafe/park/art museum. Other categories were not filtered by rating to maximize results.

Bus stops were narrowed down to 496 busstops from original 3701 by filtering on location density (exclude most busstops within 5 km of each other).

Files:

odpt-POI.csv            //all POI data records as csv file
odpt-POI-(!header).csv  //same as odpt-POI.csv file but without headers
odpt-POI.db             //SQLITE db file generated from odpt-POI-(!header).csv 
odpt-POI.json			//list of 1 Python dict/record in odpt-POI.csv as JSON output

*All above should be UTF-8 encoded.

Fields:

"busstop_id": shortname of nearest Toei Busstop from the list of 496 supported busstops
"full_busstop_id": longname version for busstop_id (matches to original busstop identifier from ODPT API)
"review_count": count of reviews from each POI page; appears capped to max 5 results by the GP-API 
"opening hours": by weekday
"photo_reference": Google photo ID which will return image from GP-API query as such: 
(must be called with maxwidth parameter or else icon? returned instead)

photo reference:
CmRaAAAAqsJHvQcQhRQjItrVvSKOuYRlD7ABjouaTgqJgzr3THIlRj8NK6lyl-IbTfZmycR1aGpoxjdBBtSpIhYl7NBlWO9dLeA9IDJx_w3SOOqslAtzVubiEWGxr_gbfLENOFMUEhAB2o0pMGBpQm9SUWY6uUrUGhRMniiTCRjw7q5QfGmvW7yog2VevA

https://maps.googleapis.com/maps/api/place/photo?maxwidth=500&photoreference=CmRaAAAAqsJHvQcQhRQjItrVvSKOuYRlD7ABjouaTgqJgzr3THIlRj8NK6lyl-IbTfZmycR1aGpoxjdBBtSpIhYl7NBlWO9dLeA9IDJx_w3SOOqslAtzVubiEWGxr_gbfLENOFMUEhAB2o0pMGBpQm9SUWY6uUrUGhRMniiTCRjw7q5QfGmvW7yog2VevA&key=[INSERT API KEY HERE]

